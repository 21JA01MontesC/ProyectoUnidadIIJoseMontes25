﻿namespace JoseJulianMontesAlvarado25VCProyectoUniudadII
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventana2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventana3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventana4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventana5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventana6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventana7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventana8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventana9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventaaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(603, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ventana2ToolStripMenuItem,
            this.ventana3ToolStripMenuItem,
            this.ventana4ToolStripMenuItem,
            this.ventana5ToolStripMenuItem,
            this.ventana6ToolStripMenuItem,
            this.ventana7ToolStripMenuItem,
            this.ventana8ToolStripMenuItem,
            this.ventana9ToolStripMenuItem,
            this.ventaaToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // ventana2ToolStripMenuItem
            // 
            this.ventana2ToolStripMenuItem.Name = "ventana2ToolStripMenuItem";
            this.ventana2ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventana2ToolStripMenuItem.Text = "Ventana2";
            this.ventana2ToolStripMenuItem.Click += new System.EventHandler(this.ventana2ToolStripMenuItem_Click);
            // 
            // ventana3ToolStripMenuItem
            // 
            this.ventana3ToolStripMenuItem.Name = "ventana3ToolStripMenuItem";
            this.ventana3ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventana3ToolStripMenuItem.Text = "Ventana3";
            this.ventana3ToolStripMenuItem.Click += new System.EventHandler(this.ventana3ToolStripMenuItem_Click);
            // 
            // ventana4ToolStripMenuItem
            // 
            this.ventana4ToolStripMenuItem.Name = "ventana4ToolStripMenuItem";
            this.ventana4ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventana4ToolStripMenuItem.Text = "Ventana4";
            this.ventana4ToolStripMenuItem.Click += new System.EventHandler(this.ventana4ToolStripMenuItem_Click);
            // 
            // ventana5ToolStripMenuItem
            // 
            this.ventana5ToolStripMenuItem.Name = "ventana5ToolStripMenuItem";
            this.ventana5ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventana5ToolStripMenuItem.Text = "Ventana5";
            this.ventana5ToolStripMenuItem.Click += new System.EventHandler(this.ventana5ToolStripMenuItem_Click);
            // 
            // ventana6ToolStripMenuItem
            // 
            this.ventana6ToolStripMenuItem.Name = "ventana6ToolStripMenuItem";
            this.ventana6ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventana6ToolStripMenuItem.Text = "Ventana6";
            this.ventana6ToolStripMenuItem.Click += new System.EventHandler(this.ventana6ToolStripMenuItem_Click);
            // 
            // ventana7ToolStripMenuItem
            // 
            this.ventana7ToolStripMenuItem.Name = "ventana7ToolStripMenuItem";
            this.ventana7ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventana7ToolStripMenuItem.Text = "Ventana7";
            this.ventana7ToolStripMenuItem.Click += new System.EventHandler(this.ventana7ToolStripMenuItem_Click);
            // 
            // ventana8ToolStripMenuItem
            // 
            this.ventana8ToolStripMenuItem.Name = "ventana8ToolStripMenuItem";
            this.ventana8ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventana8ToolStripMenuItem.Text = "Ventana8";
            this.ventana8ToolStripMenuItem.Click += new System.EventHandler(this.ventana8ToolStripMenuItem_Click);
            // 
            // ventana9ToolStripMenuItem
            // 
            this.ventana9ToolStripMenuItem.Name = "ventana9ToolStripMenuItem";
            this.ventana9ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventana9ToolStripMenuItem.Text = "Ventana9";
            this.ventana9ToolStripMenuItem.Click += new System.EventHandler(this.ventana9ToolStripMenuItem_Click);
            // 
            // ventaaToolStripMenuItem
            // 
            this.ventaaToolStripMenuItem.Name = "ventaaToolStripMenuItem";
            this.ventaaToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.ventaaToolStripMenuItem.Text = "Ventaa";
            this.ventaaToolStripMenuItem.Click += new System.EventHandler(this.ventaaToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(194, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Resuelva Esta Ecuacion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(214, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 18);
            this.label2.TabIndex = 15;
            this.label2.Text = "(X+1)/2+(X-3)/3=5";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(231, 169);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Resuelva";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(217, 209);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 17;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(603, 428);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form7";
            this.Text = "Form7";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventana2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventana3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventana4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventana5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventana6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventana7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventana8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventana9ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventaaToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
    }
}